# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'


rm(list=ls()) ###初始化编程环境
library(glmnet)
library(mvtnorm)
library(quantreg)
#生成随机数据
randomdata <- function(df, nbeta, sampleSize, n, X_cov, error_cov){
  #nbeta:真实非0参数个数
  #sampleSize:特征个数
  #n：样本个数
  trueBeta <- c(rep(0,sampleSize))
  #nbeta是beta非0数
  beta_nonzero <- c(1:nbeta)*10
  #生成非0项参数
  trueBeta[beta_nonzero] <- c(rep(1,floor(nbeta/2)), rep(-1,ceiling(nbeta/2)))  #rnorm(10,1)
  #error <- rnorm(n)*sqrt(df)
  #随机误差项分布：
  #t分布
  #卡方分布
  #正态分布
  #error <- rt(n, df)*sqrt(error_cov)
  error <- rcauchy(n, location=0, scale=df)*sqrt(error_cov)     #error <- c(rnorm(100))
  #X <- matrix(rnorm(sampleSize*n)*10, nrow = n)
  #Xmat <- rmvnorm(n,rep(0,sampleSize),diag(sampleSize))
  #r2 <- cov(Xmat)
  r2 <- diag(sampleSize)
  X<-rmvnorm(n,rep(0,sampleSize),r2)*sqrt(X_cov)
  Y <- X %*% trueBeta + error
  return(list(X, Y, trueBeta, error))
}

#X:控制变量
#Y:相应变量
#nbeta:需要选择的变量个数
#' @export
slasso <- function(X, Y, nbeta){
  time_start <- proc.time ()
  sampleSize <- dim(X)[1]
  n <- dim(X)[0]
  #df是误差项t分布的自由度
  iteration <- function(Sk1, X, Y){
    sampleSize <- ncol(X)
    Sk_complement <- setdiff(c(1:sampleSize), Sk1)            #剩下的！！
    X_select <- X[, Sk1]           ###
    X_cp <- X[, Sk_complement]
    H <- X_select %*% solve(t(X_select) %*% X_select) %*% t(X_select)
    X_cp_wave <- (diag(nrow(X)) - H) %*% X_cp
    Y_cp_wave <- (diag(nrow(X)) - H) %*% Y
    res <- abs(t(X_cp_wave) %*% Y_cp_wave)
    #id <- which(res==max(res),arr.ind=TRUE)
    index <- Sk_complement[which.max(res)]                   #迭代的返回值，第二步为75
    return(union(Sk1, index))
  }
  Sk1 <- which.max(abs(t(X) %*% Y))
  #迭代到10次
  nn <- nbeta - 1
  for (k in c(1:nn)) {                      #每次迭代相当于只改变selected的部分
    Sk1 <- iteration(Sk1, X, Y)
  }
  Sk1
}
help(slasso)

